package com.amdocs.SpringBasicCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBasicCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
